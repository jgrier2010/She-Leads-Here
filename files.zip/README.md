# She Leads Here — Landing Page

The new sheleadshere.org landing page. Premium, conversion-optimized, fully responsive.

---

## What's in this folder

```
slh-website/
├── index.html          ← The page itself (HTML structure + content)
├── styles.css          ← All the visual styling (colors, typography, layout)
├── script.js           ← Interactive behavior (counter, toggle, sticky CTA)
├── assets/
│   ├── logo.svg        ← SLH logo (purple)
│   ├── coach-leslie.png
│   ├── coach-ouriana.png
│   └── og-image.png    ← Social share preview image
└── README.md           ← This file
```

---

## Deploy (5 minutes, no code required)

1. **Open** your `She-Leads-Here` GitHub repo in the browser
2. **Click** "Add file" → "Upload files"
3. **Drag and drop** ALL the files from this folder (including the `assets` folder)
4. **Scroll down**, type "Initial site upload" in the commit message
5. **Click** "Commit changes"
6. **Wait 30 seconds** — Vercel auto-detects the change and deploys
7. **Visit** `https://she-leads-here.vercel.app` — you'll see the live site

---

## How to edit (no developer needed)

### Change the founding member count
Open `script.js`. Line 9:
```js
const FOUNDING_COUNT = 47;        // <-- change this number
```
Update the number, save, push to GitHub. Live in 30 seconds.

### Change copy / text
Open `index.html`. Find the section, change the text. Save. Push to GitHub.

### Change colors
Open `styles.css`. Top of file under `/* TOKENS */`. Brand colors are CSS variables:
```css
--purple: #4F1964;
--gold:   #F5C842;
--cream:  #F5F1E8;
```

### Add a coach
Open `index.html`. Find the `<!-- Coach 2: Ouriana Walker -->` section. Copy that whole block. Paste below it. Update the name, image, bio. Add the headshot to the `assets/` folder.

### Update the price
Open `index.html`. Find `data-monthly` and `data-annual` attributes inside the tier section. Change the numbers.

---

## What's working

- ✅ Hero with animated founding-member counter
- ✅ Live progress bar (animates on page load)
- ✅ Coach showcase grid (using your existing card designs)
- ✅ Two-tier comparison (Wayfinder vs Truthbearer)
- ✅ Monthly / Annual toggle (annual selected by default)
- ✅ Founder quote section
- ✅ FAQ accordion (6 honest answers)
- ✅ Final CTA section
- ✅ Sticky CTA bar that appears after you scroll past the hero
- ✅ Full schema.org markup for SEO + AI search
- ✅ Open Graph tags for LinkedIn / social sharing
- ✅ Mobile responsive (looks good on every device)
- ✅ Premium fonts: Fraunces (display) + DM Sans (body)
- ✅ Smooth scroll and subtle scroll reveal animations
- ✅ Accessible (semantic HTML, ARIA labels, keyboard nav)

---

## What's NOT in here yet (Phase 2)

- Coach individual profile pages
- Coach Match Quiz
- Blog / content system
- Member testimonials section (placeholder ready)
- Booking integration (Calendly embed)
- Marketplace / partner listings
- Email capture form (just CTA buttons for now — they need to be wired to Stripe / a checkout flow)

We'll add these one at a time as we iterate.

---

## Where the CTAs go

Right now, every "Become a Founding Member" button links to `#join` (scrolls to the final CTA section). When you're ready to take payment, we replace that with:
- A direct link to your Stripe checkout, OR
- A link to your Circle signup flow with the founding promo code, OR
- A custom checkout page we build on this same site

Tell me which one and I'll wire it up.

---

## Design notes

- **Aesthetic**: Editorial luxury. Think Vanity Fair meets a private members club.
- **Typography**: Fraunces (a beautiful contemporary serif with character) for headlines, DM Sans for body
- **Color**: Royal purple `#4F1964` is dominant, gold `#F5C842` is the action color, cream and ink hold everything together
- **Motion**: Subtle. Pulse animations on the founding counter to convey scarcity. Scroll reveals to create rhythm. Hover states that feel premium, not gimmicky.

---

## Questions / iterations

When you want changes, just describe them in chat:
- "Make the counter bigger"
- "Add a testimonial from [member name]"
- "The brief copy should say [X] instead"
- "Add coach [name] with [photo] and [bio]"
- "I want a section above the FAQ about what's inside Circle"

I'll update the code, give you the new files, you push to GitHub.
